create table Publisher
(
    Publisher varchar(255)
        primary key
);

