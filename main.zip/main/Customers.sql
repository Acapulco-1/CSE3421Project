create table Customers
(
    Account_ID int
        primary key,
    FirstName  varchar(255),
    LastName   varchar(255),
    PhoneNo    int,
    Balance    int,
    BooksTotal int
);

