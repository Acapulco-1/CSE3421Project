create table Books
(
    ISBN      bigint
        primary key,
    Year      int,
    Title     varchar(255),
    Category  varchar(255),
    Publisher varchar(255)
        references Publisher
);

